package Kotlin

fun main() {

    // val (define variable), name, type (Int, String etc) then value
    val name : String = "malware";
    val age : Int = 20;

    // var is mutable mean value can be changed and val is immutable mean val can't be changed
    var degree : String = "BS IT";
    var year: Int = 4;

    println("Your name is $name, you age is $age, you degree is $degree and you graduation year is $year. ");


}
