package Kotlin

fun main() {
    var i=0

    // while loop
    while (i<5){
        println(i)
        i++
    }

    // do while loop
    do {
        println(i)
        i++
    }while (i>10)

}