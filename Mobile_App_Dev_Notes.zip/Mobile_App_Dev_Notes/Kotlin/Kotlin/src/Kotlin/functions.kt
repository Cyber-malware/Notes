package Kotlin


fun main(){
    val a=1
    val b=2

    // lamda express pass the fun as parameter
    val result = add(b=b,a=a,operation={a,b -> a+b})
    print(result)
}

// Higher Order function
// last Int define return type is integer
fun add (a:Int, b:Int, operation: (Int, Int) -> Int ) :Int{  // passing the operation function as parameter inside another function and this (Int, Int) -> Int represent parameter + return type
    // function contain three things name, input/output parameter, fun body and return type
    return operation(a,b)
}

fun reset(){
    // TOdo fun with no return type
}