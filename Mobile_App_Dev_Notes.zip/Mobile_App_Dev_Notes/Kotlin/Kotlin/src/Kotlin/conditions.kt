package Kotlin

fun condition(){

    // when condition in kotlin
    val uage : Int = 15;
    when {
        uage > 18 -> {
            println("You are Men")
        }
        uage > 12 && uage <= 18 -> {
            println("You are young")
        }
        else -> {
            println("You are child")
        }
    }
}