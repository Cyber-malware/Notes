package Kotlin

fun main() {

    // an array to store multiple values
    val list = listOf("Malware","Cyber","ITguy","Developer", "Android")

    for (name in list){
        println(name)
    }

    // step 2 mean increase two digits
    for (i in 1..10 step 2){
        if (i==5) break  // break when value equal to 5 or we can also use continue here
        println(i)
    }
}