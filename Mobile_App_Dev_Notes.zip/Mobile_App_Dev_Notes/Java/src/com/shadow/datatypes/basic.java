package com.shadow.datatypes;

public class basic {
    public static void main(String[] args) {
        System.out.println("Its my first program in java");
    }
}